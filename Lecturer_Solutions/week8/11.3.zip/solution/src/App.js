import React from "react";
import NewSurvey from "./NewSurvey.component";
import "./App.css";

const App = () => {
  return (
    <div>
      <NewSurvey></NewSurvey>
    </div>
  );
};

export default App;
