import React from 'react';

const StreamEdit = props => {
  console.log(props);
  return <div>StreamEdit</div>;
};

export default StreamEdit;
