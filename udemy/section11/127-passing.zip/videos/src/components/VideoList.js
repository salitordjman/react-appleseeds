import React from 'react';

const VideoList = props => {
  return <div>{props.videos.length}</div>;
};

export default VideoList;
