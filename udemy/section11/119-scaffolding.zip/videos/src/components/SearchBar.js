import React from 'react';

class SearchBar extends React.Component {
  render() {
    return <div>SearchBar</div>;
  }
}

export default SearchBar;
