import React from 'react';

const VideoItem = props => {
  return <div>Video Item</div>;
};

export default VideoItem;
