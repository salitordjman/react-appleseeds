const Home = () => {
  const styles = {
    height: "calc(100vh - 5vh)",
    background: "red",
  };
  return <div style={styles}>My Home</div>;
};
export default Home;
