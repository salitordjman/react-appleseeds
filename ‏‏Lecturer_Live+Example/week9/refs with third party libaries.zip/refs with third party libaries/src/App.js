import "./App.css";
import MyChart from "./MyChart";
function App() {
  return (
    <div>
      <MyChart />
    </div>
  );
}

export default App;
