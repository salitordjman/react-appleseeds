import axios from 'axios';

export default axios.create({
  baseURL: 'https://605b218e27f0050017c063ab.mockapi.io/mid-project',
});
