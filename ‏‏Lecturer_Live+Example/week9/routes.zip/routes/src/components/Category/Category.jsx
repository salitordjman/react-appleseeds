import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Api from '../../api/Api.js';

class Category extends Component {
  state = { errorMes: null, data: [] };
  async componentDidMount() {
    try {
      const data = await Api.get('');
      this.setState({ data: data.data });
    } catch (err) {
      console.log(err);
    }
  }

  insertStreets = () => {
    return this.state.data.map((e) => {
      return (
        <Link key={e.id} to={`/category/${e.id}`}>
          <div style={{ border: '1px solid black' }}>
            <h4>{e.img}</h4>
            <img src={e.animals} alt={e.img} style={{ height: '300px' }} />
          </div>
        </Link>
      );
    });
  };

  render() {
    return (
      <div>
        <h2>Category</h2>
        {this.insertStreets()}
      </div>
    );
  }
}

export default Category;
