import React, { Component } from 'react';
import Api from '../../api/Api';
class CategoryDetails extends Component {
  state = { data: {} };

  async componentDidMount() {
    try {
      const data = await Api.get(this.props.details.city + '/images');
      console.log(data);
      this.setState({ data: data.data });
    } catch (err) {}
  }

  render() {
    console.log('brr');
    return (
      <div>
        <h1>{this.state.data.img}</h1>
      </div>
    );
  }
}

export default CategoryDetails;
