import React, { Component } from 'react';

class Home extends Component {
  state = { st: this.props.myState };

  render() {
    return <h1>Hello</h1>;
  }
}

export default Home;
