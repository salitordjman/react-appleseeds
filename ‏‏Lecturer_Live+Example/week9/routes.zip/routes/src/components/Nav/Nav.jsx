import React from 'react';
import { Link } from 'react-router-dom';
import './style.css';
function Nav() {
  return (
    <div className='nav'>
      <Link to='/category' className='button'>
        Category
      </Link>
      <Link to='/' className='button'>
        Home
      </Link>
    </div>
  );
}

export default Nav;
