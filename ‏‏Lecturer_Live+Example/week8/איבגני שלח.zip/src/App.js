import TodoList from './components/TodoList/TodoList.component';

export default function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}


