import "./global-score.styles.css";
const GlobalScore = ({ score }) => {
  return <div className="global-score">{score}</div>;
};
export default GlobalScore;
